"""
Proj: resolution-net
Date: 7/28/18
Written by Yuezun Li
--------------------------
"""