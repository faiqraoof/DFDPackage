"""
Proj: PyCVApp
Date: 4/13/18
Written by Yuezun Li
--------------------------
"""